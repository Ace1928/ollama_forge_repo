"""
Centralized model configuration for the Ollama API client.

This module defines default models and fallback options to ensure
consistency across all parts of the application.
"""

# Primary and backup model definitions
DEFAULT_CHAT_MODEL = "deepseek-r1:1.5b"
BACKUP_CHAT_MODEL = "qwen2.5:0.5b"

# Use the same models for embedding to ensure semantic consistency
DEFAULT_EMBEDDING_MODEL = DEFAULT_CHAT_MODEL
BACKUP_EMBEDDING_MODEL = BACKUP_CHAT_MODEL

# Model selection timeout (seconds) before falling back to backup model
MODEL_FALLBACK_TIMEOUT = 180
