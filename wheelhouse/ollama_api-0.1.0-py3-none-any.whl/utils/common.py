#!/usr/bin/env python3
"""
Common utilities for Ollama API examples and client.
"""

import logging
import json
import asyncio
import requests
import aiohttp
from colorama import Fore, Style
from typing import Any, Dict, Optional, TypeVar

from ollama_api.exceptions import (
    OllamaAPIError, ConnectionError, TimeoutError, 
    ModelNotFoundError, ServerError, InvalidRequestError
)

# Configure logger
logger = logging.getLogger(__name__)

# Default Ollama API URL
DEFAULT_OLLAMA_API_URL = "http://localhost:11434/"

# Default model to use across the package
DEFAULT_MODEL = "deepseek-r1:1.5b"
ALTERNATIVE_MODEL = "qwen2.5:0.5b"

# Type variable for generic return types
T = TypeVar('T')

def print_header(title: str) -> None:
    """
    Print a formatted header for the example.
    
    Args:
        title: The title to display
    """
    print(f"\n{Fore.CYAN}{'=' * 60}{Style.RESET_ALL}")
    print(f"{Fore.CYAN}{title.center(60)}{Style.RESET_ALL}")
    print(f"{Fore.CYAN}{'=' * 60}{Style.RESET_ALL}\n")

def print_success(message: str) -> None:
    """
    Print a success message.
    
    Args:
        message: The message to display
    """
    print(f"{Fore.GREEN}✓ {message}{Style.RESET_ALL}")

def print_error(message: str) -> None:
    """
    Print an error message.
    
    Args:
        message: The message to display
    """
    print(f"{Fore.RED}✗ {message}{Style.RESET_ALL}")

def print_warning(message: str) -> None:
    """
    Print a warning message.
    
    Args:
        message: The message to display
    """
    print(f"{Fore.YELLOW}⚠ {message}{Style.RESET_ALL}")

def print_info(message: str) -> None:
    """
    Print an info message.
    
    Args:
        message: The message to display
    """
    print(f"{Fore.BLUE}ℹ {message}{Style.RESET_ALL}")

def print_json(data: Any) -> None:
    """
    Print formatted JSON data.
    
    Args:
        data: The JSON data to display
    """
    print(json.dumps(data, indent=2))

def make_api_request(
    method: str, 
    endpoint: str, 
    data: Optional[Dict[str, Any]] = None, 
    params: Optional[Dict[str, Any]] = None, 
    base_url: str = DEFAULT_OLLAMA_API_URL,
    timeout: int = 60
) -> Optional[requests.Response]:
    """
    Make an API request to the Ollama API.
    
    Args:
        method: The HTTP method (GET, POST, etc.)
        endpoint: The API endpoint (e.g., "/api/generate")
        data: The request data (for POST requests)
        params: The query parameters (for GET requests)
        base_url: The base URL for the Ollama API
        timeout: Request timeout in seconds
        
    Returns:
        The response object or None if the request failed
        
    Raises:
        ConnectionError: When the connection to the Ollama server fails
        TimeoutError: When the request times out
        InvalidRequestError: When the request contains invalid parameters
        ModelNotFoundError: When the requested model is not found
        ServerError: When the server returns a 5xx error
        OllamaAPIError: For other API errors
    """
    url = f"{base_url}{endpoint}"
    
    try:
        logger.debug(f"Making {method} request to {url}")
        
        if method.upper() == "GET":
            response = requests.get(url, params=params, timeout=timeout)
        elif method.upper() == "POST":
            response = requests.post(url, json=data, timeout=timeout)
        elif method.upper() == "DELETE":
            response = requests.delete(url, json=data, timeout=timeout)
        elif method.upper() == "PUT":
            response = requests.put(url, json=data, timeout=timeout)
        else:
            logger.error(f"Unsupported HTTP method: {method}")
            raise InvalidRequestError(f"Unsupported HTTP method: {method}")
        
        # Handle HTTP errors
        if response.status_code >= 400:
            error_msg = f"HTTP {response.status_code}: {response.text}"
            
            if response.status_code == 404:
                if data and data.get("model") is not None or endpoint.endswith("model"):
                    raise ModelNotFoundError(f"Model not found: {error_msg}")
                else:
                    raise InvalidRequestError(f"Resource not found: {error_msg}")
            elif response.status_code >= 500:
                raise ServerError(f"Server error: {error_msg}")
            else:
                raise OllamaAPIError(f"API error: {error_msg}")
        
        logger.debug(f"Request successful: {response.status_code}")
        return response
        
    except requests.exceptions.Timeout:
        logger.error(f"Request timed out after {timeout} seconds")
        print_error(f"Request timed out after {timeout} seconds")
        raise TimeoutError(f"Request timed out after {timeout} seconds")
    except requests.exceptions.ConnectionError as e:
        logger.error(f"Connection error: {e}")
        print_error(f"Connection error: Is the Ollama server running at {base_url}?")
        raise ConnectionError(f"Failed to connect to Ollama at {base_url}: {str(e)}")
    except requests.exceptions.RequestException as e:
        logger.error(f"Request error: {e}")
        print_error(f"Request error: {e}")
        raise OllamaAPIError(f"Request error: {str(e)}")

async def async_make_api_request(
    method: str, 
    endpoint: str, 
    data: Optional[Dict[str, Any]] = None, 
    params: Optional[Dict[str, Any]] = None, 
    base_url: str = DEFAULT_OLLAMA_API_URL,
    timeout: int = 60
) -> Dict[str, Any]:
    """
    Make an asynchronous API request to the Ollama API.
    
    Args:
        method: The HTTP method (GET, POST, etc.)
        endpoint: The API endpoint (e.g., "/api/generate")
        data: The request data (for POST requests)
        params: The query parameters (for GET requests)
        base_url: The base URL for the Ollama API
        timeout: Request timeout in seconds
        
    Returns:
        The JSON response as a dictionary
        
    Raises:
        ConnectionError: When the connection to the Ollama server fails
        TimeoutError: When the request times out
        InvalidRequestError: When the request contains invalid parameters
        ModelNotFoundError: When the requested model is not found
        ServerError: When the server returns a 5xx error
        OllamaAPIError: For other API errors
    """
    url = f"{base_url}{endpoint}"
    
    try:
        logger.debug(f"Making async {method} request to {url}")
        
        async with aiohttp.ClientSession() as session:
            if method.upper() == "GET":
                request_func = session.get
            elif method.upper() == "POST":
                request_func = session.post
            elif method.upper() == "DELETE":
                request_func = session.delete
            elif method.upper() == "PUT":
                request_func = session.put
            else:
                logger.error(f"Unsupported HTTP method: {method}")
                raise InvalidRequestError(f"Unsupported HTTP method: {method}")
            
            async with request_func(
                url, 
                json=data, 
                params=params, 
                timeout=aiohttp.ClientTimeout(total=timeout)
            ) as response:
                # Handle HTTP errors
                if response.status >= 400:
                    error_text = await response.text()
                    error_msg = f"HTTP {response.status}: {error_text}"
                    
                    if response.status == 404:
                        if data and "model" in data:
                            raise ModelNotFoundError(f"Model not found: {error_msg}")
                        else:
                            raise InvalidRequestError(f"Resource not found: {error_msg}")
                    elif response.status >= 500:
                        raise ServerError(f"Server error: {error_msg}")
                    else:
                        raise OllamaAPIError(f"API error: {error_msg}")
                
                logger.debug(f"Async request successful: {response.status}")
                return await response.json()
                
    except aiohttp.ClientConnectorError as e:
        logger.error(f"Connection error: {e}")
        raise ConnectionError(f"Failed to connect to Ollama at {base_url}: {str(e)}")
    except asyncio.TimeoutError:
        logger.error(f"Request timed out after {timeout} seconds")
        raise TimeoutError(f"Request timed out after {timeout} seconds")
    except aiohttp.ClientError as e:
        logger.error(f"Request error: {e}")
        raise OllamaAPIError(f"Request error: {str(e)}")
