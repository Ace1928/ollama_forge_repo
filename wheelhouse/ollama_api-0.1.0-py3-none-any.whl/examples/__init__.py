"""
Example scripts demonstrating the usage of the Ollama API client.
"""
