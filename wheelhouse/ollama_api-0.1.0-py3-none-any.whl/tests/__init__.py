"""
Test suite for the Ollama API client.

This package contains tests for all components of the Ollama API client,
including the core client, examples, and utilities.
"""
