#!/usr/bin/env python3
"""
Tests for the version functionality.
"""

import unittest
from unittest.mock import patch, Mock
import sys
import os
from typing import Any, Dict, Optional

# Try to import as a package first, then try relative imports
try:
    from ollama_api.utils.common import DEFAULT_OLLAMA_API_URL
    from ollama_api.examples.version_example import get_ollama_version
except ImportError:
    # Add parent directory to path for direct execution
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))
    try:
        from ollama_api.utils.common import DEFAULT_OLLAMA_API_URL
        from ollama_api.examples.version_example import get_ollama_version
    except ImportError as e:
        print(f"Error importing required modules: {e}")
        print("Please install the package using: pip install -e /path/to/ollama_api")
        sys.exit(1)


class TestVersion(unittest.TestCase):
    """Test cases for version functionality."""
    
    @patch('requests.get')
    def test_get_version_success(self, mock_get: Any) -> None:
        """Test successful version retrieval."""
        # Setup mock
        mock_response = Mock()
        mock_response.json.return_value = {"version": "0.1.0"}
        mock_response.raise_for_status = Mock()
        mock_get.return_value = mock_response
        
        # Call function
        result = get_ollama_version()
        
        # Assert results
        mock_get.assert_called_once_with(f"{DEFAULT_OLLAMA_API_URL}/api/version")
        self.assertEqual(result, {"version": "0.1.0"})
    
    @patch('requests.get')
    def test_get_version_custom_url(self, mock_get: Any) -> None:
        """Test version retrieval with custom URL."""
        # Setup mock
        mock_response = Mock()
        mock_response.json.return_value = {"version": "0.1.0"}
        mock_response.raise_for_status = Mock()
        mock_get.return_value = mock_response
        
        # Call function with custom URL
        custom_url = "http://custom-ollama-server:11434"
        result = get_ollama_version(custom_url)
        
        # Assert results
        mock_get.assert_called_once_with(f"{custom_url}/api/version")
        self.assertEqual(result, {"version": "0.1.0"})
    
    @patch('ollama_api.examples.version_example.requests.get')
    def test_get_version_failure(self, mock_get: Any) -> None:
        """Test version retrieval failure."""
        # Setup mock using the correct import path
        mock_get.side_effect = Exception("Connection error")
        
        # Call function
        result = get_ollama_version()
        
        # Assert results
        mock_get.assert_called_once()
        self.assertIsNone(result)
    
    @patch('ollama_api.examples.version_example.requests.get')
    def test_get_version_http_error(self, mock_get: Any) -> None:
        """Test version retrieval with HTTP error."""
        # Setup mock using the correct import path
        mock_response = Mock()
        mock_response.raise_for_status.side_effect = Exception("HTTP Error 404")
        mock_get.return_value = mock_response
        
        # Call function
        result = get_ollama_version()
        
        # Assert results
        mock_get.assert_called_once()
        self.assertIsNone(result)


if __name__ == '__main__':
    unittest.main()
