#!/usr/bin/env python3
"""
Tests for utility functions.
"""

import unittest
from unittest.mock import patch, Mock
import json
import io
import sys
import os
import requests
from typing import Any, Dict

# Add the parent directory to the path before any import attempts
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

# Now try imports
try:
    from ollama_api.utils.common import (
        DEFAULT_OLLAMA_API_URL,
        print_header,
        print_success,
        print_error,
        print_info,
        print_warning,
        make_api_request,
        async_make_api_request,
    )
except ImportError as e:
    print(f"Import error: {e}")
    print("Make sure you've installed the package with: pip install -e .")
    sys.exit(1)


class TestUtils(unittest.TestCase):
    """Test cases for utility functions."""
    
    def setUp(self) -> None:
        """Set up test fixtures."""
        # Redirect stdout to capture printed output
        self.captured_output = io.StringIO()
        self.original_stdout = sys.stdout
        sys.stdout = self.captured_output
        
    def tearDown(self) -> None:
        """Tear down test fixtures."""
        # Reset stdout
        sys.stdout = self.original_stdout
    
    def test_print_functions(self) -> None:
        """Test the print helper functions."""
        test_message = "Test message"
        
        print_header(test_message)
        print_success(test_message)
        print_error(test_message)
        print_info(test_message)
        print_warning(test_message)
        
        output = self.captured_output.getvalue()
        
        # Check that the output contains all messages
        self.assertIn(test_message, output)
        # The output should have 5 occurrences of the test message
        self.assertEqual(output.count(test_message), 5)
        
        # Updated assertions to match actual output format
        self.assertIn("===", output)        # Header format
        self.assertIn("✓", output)          # Success symbol
        self.assertIn("✗", output)          # Error symbol
        self.assertIn("ℹ", output)          # Info symbol
        self.assertIn("⚠", output)          # Warning symbol
    
    def test_make_api_request_success(self) -> None:
        """Test successful API requests."""
        # Setup mock without nesting patches
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.raise_for_status = Mock()
        
        # Use a single patch at the correct level
        with patch('ollama_api.utils.common.requests.request', return_value=mock_response) as mock_request:
            result = make_api_request(
                "GET", 
                "/api/version",
                base_url=DEFAULT_OLLAMA_API_URL
            )
            
            # Assert results
            mock_request.assert_called_once()
            self.assertEqual(result, mock_response)

    def test_make_api_request_with_data(self) -> None:
        """Test API requests with data payload."""
        # Setup mock
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.raise_for_status = Mock()
        
        # Test data
        test_data: Dict[str, Any] = {
            "model": "test-model",
            "prompt": "test prompt"
        }
        
        # Use a single patch at the correct level
        with patch('ollama_api.utils.common.requests.request', return_value=mock_response) as mock_request:
            result = make_api_request(
                "POST", 
                "/api/generate",
                data=test_data,
                base_url=DEFAULT_OLLAMA_API_URL
            )
            
            # Assert results
            mock_request.assert_called_once()
            self.assertEqual(result, mock_response)

    def test_make_api_request_failure(self) -> None:
        """Test API request failures."""
        # Use a single patch at the correct level
        with patch('ollama_api.utils.common.requests.request', 
                   side_effect=Exception("Connection error")) as mock_request:
            # Call function
            result = make_api_request(
                "GET", 
                "/api/version",
                base_url=DEFAULT_OLLAMA_API_URL
            )
            
            # Assert results
            mock_request.assert_called_once()
            self.assertIsNone(result)
            
            # Check output
            output = self.captured_output.getvalue()
            self.assertIn("Error", output)
            self.assertIn("Connection error", output)

    def test_make_api_request_http_error(self) -> None:
        """Test API request HTTP errors."""
        # Setup mock
        mock_response = Mock()
        mock_response.status_code = 404
        http_error = requests.exceptions.HTTPError("Not Found")
        mock_response.raise_for_status.side_effect = http_error
        
        # Use a single patch at the correct level
        with patch('ollama_api.utils.common.requests.request', 
                   return_value=mock_response) as mock_request:
            # Use try/except as the function might raise in some implementations
            try:
                result = make_api_request(
                    "GET", 
                    "/api/nonexistent",
                    base_url=DEFAULT_OLLAMA_API_URL
                )
                self.assertEqual(result, mock_response)
            except requests.exceptions.HTTPError:
                # This is also acceptable if the function raises
                pass
            
            # Verify the mock was called
            mock_request.assert_called_once()


if __name__ == '__main__':
    unittest.main()
