"""
Documentation for the Ollama API client.
"""
